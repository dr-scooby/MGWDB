
package utils;
import Data.Laptop;
import java.util.*;


/**
 * Handle the comma delimited file, 
 * bulk data
 * @author jismailx
 */
public class ProcessData {
    // ArrayList of Laptops
    private ArrayList<Laptop> arrl;
    
    
    public ProcessData(){
        arrl = new ArrayList<Laptop>();
    }
    
    
    public ProcessData(String[] strs){
        this();
        // convert the String array to an ArrayList
        process(strs);
    }
    
    public ProcessData(String st){
      this();
      process(st);
    }
    
    
    private void process(String s){
        String serial = "";
        String model = "";
        String manuf = "";
        Laptop lap = null;
        
        String[] args = s.split("\\r?\\n"); // split by new line
        for(int i = 0; i < args.length; i++){
            String[] line = args[i].split(","); // split by comma
            System.out.println(i + " " + args[i]);
            lap = new Laptop();
            for(int x = 0 ; x < line.length; x++){
                System.out.println("x: " + x + " " + line[x]);
                switch(x){
                    case 0: 
                        serial = line[x];
                        lap.setSerial(serial);
                        break;
                    case 1:
                        model = line[x];
                        lap.setModel(model);
                        break;
                    case 2:
                        manuf = line[x];
                        lap.setManufacture(manuf);
                        break;
                }
            }
            arrl.add(lap);
        }
    }
   
    
    public ArrayList<Laptop> getData(){
        return arrl;
    }
    
    // get String array, should be a String of lines or line
    // eg: 5cg, 850 g8, HP
    public void process(String[] strs){
        String serial = "";
        String model = "";
        String manufacture = "";
        String s = "";
        Laptop lap = null;
        
        for(int i = 0; i < strs.length; i++){
            System.out.println(i + " : " + strs[i]);
        }
        
    }
}
