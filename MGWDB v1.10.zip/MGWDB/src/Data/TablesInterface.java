/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author jismailx
 */
public interface TablesInterface {
    
    String table_laptopinventory = "laptopinventory";
    
    String table_assignedlaptop = "assignedlaptop";
    
    String table_history = "history";
    
    String sql_create_laptopinventory = "create table laptopinventory(Serial varchar(25) primary key not null, Model varchar(50), Manufacture varchar(50), Notes varchar(200), Assigned varchar(5))";
    
    String sql_create_assignedlaptop = "create table assignedlaptop(laptopserial varchar(25) not null primary key, username varchar(80) not null)";
    
    String sql_create_history = "create table history(id int primary key auto_increment, action varchar(200), serial varchar(30), whouser varchar(80))";
    
}
