/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

/**
 *
 * @author jismailx
 */
public class Laptop {
    
    private String serial;
    private String model;
    private String manufacture;
    private String notes;
    
    /**
     * Default Constructor
     */
    public Laptop(){
        serial = "";
        model = "";
        manufacture = "";
        notes = "";
    }

    /**
     * 
     * @param serial
     * @param model
     * @param manufacture 
     */
    public Laptop(String serial, String model, String manufacture){
        this.serial = serial;
        this.model = model;
        this.manufacture = manufacture;
    }

    /**
     * 
     * @return String notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * set Notes
     * @param notes 
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    /**
     * @return the serial
     */
    public String getSerial() {
        return serial;
    }

    /**
     * @param serial the serial to set
     */
    public void setSerial(String serial) {
        this.serial = serial;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model the model to set
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * @return the manufacture
     */
    public String getManufacture() {
        return manufacture;
    }

    /**
     * @param manufacture the manufacture to set
     */
    public void setManufacture(String manufacture) {
        this.manufacture = manufacture;
    }

    @Override
    public String toString() {
        return "Laptop{" + "serial=" + serial + ", model=" + model + ", manufacture=" + manufacture + '}';
    }
    
    
}
