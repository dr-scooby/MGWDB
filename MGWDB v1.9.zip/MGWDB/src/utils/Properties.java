/*
 * Get the info from the properties file
 * User name, password, DB name, IP address of server
 */
package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 *
 * @author jismailx
 */
public class Properties {
    
    private String user;
    private String pass;
    private String ip;
    private String dbname;
    
    public Properties(){
        java.util.Properties props = new java.util.Properties();
        String url = "dbproperties.properties";
        try{
        InputStream input = new FileInputStream(url);
        props.load(input);
        System.out.println("DB user: " + props.getProperty("db.user"));
        user = props.getProperty("db.user");
        
        System.out.println("DB password: " + props.getProperty("db.password"));
        pass = props.getProperty("db.password");
        
        System.out.println("DB ip: " + props.getProperty("db.ip"));
        ip = props.getProperty("db.ip");
        
        System.out.println("DB Name: " + props.getProperty("db.name"));
        dbname = props.getProperty("db.name");
        }catch(IOException io){
            System.err.print(io);
        }
    }
    
    /**
     * 
     * @return String User 
     */
    public String getUser(){
        return user;
    }
    
    /**
     * 
     * @return String Password 
     */
    public String getPassword(){
        return pass;
    }
    
    /**
     * 
     * @return String IP address of Server 
     */
    public String getIP(){
        return ip;
    }
    
    /**
     * 
     * @return String DB Name 
     */
    public String getDBName(){
        return dbname;
    }
}
