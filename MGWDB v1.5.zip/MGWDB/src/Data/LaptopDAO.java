/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;

import Database.DBModel;
import java.sql.*;
import java.util.*;

/**
 *
 * @author jismailx
 */
public class LaptopDAO extends DAO{
    
    
    public LaptopDAO(){
    }
    
    /**
     * 
     * @param db DBModel
     */
    public LaptopDAO(DBModel db){
        super(db);
    }
    
    public void add(String serial){
        
    }
    
    
   
    // add Laptop to the DB
    public void addLaptop(Laptop l) throws SQLException{
        
        
        Connection con = dbmodel.getConnection();
        // check if table exists
        if( !tableExists("laptopinventory")){
            // doesn't exist, need to create it
            createTable();
        }
        
        String sql = "insert into laptopinventory(Serial, Model, Manufacture, Notes, assigned ) values(?,?,?,?,?);";
        System.out.println("insert into DB:> " + l + " " + l.getNotes());
        
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, l.getSerial());
        pst.setString(2, l.getModel());
        pst.setString(3, l.getManufacture());
        pst.setString(4, l.getNotes());
        pst.setString(5, "no"); // set assigned to no, testing only
        int x = pst.executeUpdate();
        System.out.println("X: " + x);       
        
    }
    
    // update the Laptop to the DB
    public void updateLaptop(Laptop la)throws SQLException{
        String sql = "update laptopinventory set Model=?,  Manufacture=?, Notes=? where Serial=?";
        
        Connection con = dbmodel.getConnection();
        
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, la.getModel());
        pst.setString(2, la.getManufacture());
        pst.setString(3, la.getNotes());
        pst.setString(4, la.getSerial());
        int x = pst.executeUpdate();
        System.out.println("update X:" + x);
    }
    
    // create table
    public void createTable() throws SQLException{
        String sql = "create table laptopinventory(Serial varchar(25) primary key not null, Model varchar(50), Manufacture varchar(50), Notes varchar(200), Assigned varchar(5))";
        Connection con = dbmodel.getConnection();
        Statement st = con.createStatement();
        st.executeUpdate(sql);
        
    }
    
    /**
	 * Check if table exists
	 * @param targetTableName String
	 * @return boolean true if exists, false if doens't exist
	 * @throws SQLException
	 */
	public boolean tableExists(String targetTableName) throws SQLException {
            Connection con = dbmodel.getConnection();
            DatabaseMetaData databaseMetaData = con.getMetaData();
            ResultSet resultSet = null;
            String tableName = null;

            try {
                    resultSet = databaseMetaData.getTables(con.getCatalog(), "%", "%", null);
                    while (resultSet.next()) {
                            tableName = resultSet.getString("TABLE_NAME");
                            if (tableName.equalsIgnoreCase(targetTableName)) {
                                    return true;
                            }
                    }
            } finally {
                    resultSet.close();
            }

            return false;
	}
    
    
    public ArrayList<Laptop> searchSerialID(String serialid)throws SQLException {
        
        // check if table exists
        if( !tableExists("laptopinventory")){
            System.out.println("laptopinventory doesn't exist");
            // doesn't exist, need to create it
            createTable();
        }else
            System.out.println("laptopinventory EXISTS");
        
        Laptop l = null;
        // use ArrayList to hold objects
        ArrayList<Laptop> laps = new ArrayList<Laptop>(); 
        
        String sql = "select * from laptopinventory where Serial like '%" + serialid + "%'";
        Connection con = dbmodel.getConnection();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next()){
            String serial = rs.getString("Serial");
            String model = rs.getString("Model");
            String manuf = rs.getString("Manufacture");
            String notes = rs.getString("Notes");
            l = new Laptop(serial, model, manuf);
            l.setNotes(notes);
            System.out.println(l);
            laps.add(l); // add laptop to the ArrayList
        }
        
        /*
        String searchsql = "select * from laptopinventory where Serial like '%" + searchserial + "%'";
            System.out.println(searchsql);
            
            rs = stmt.executeQuery(searchsql);
            //rs.getMetaData()
            //found = true;
            tempsearch = new ArrayList();
            Laptop tlap ;
            
            int countrow = 0;
            
            while(rs.next()){
                String serial = rs.getString(1);
                String type = rs.getString(2);
                String manu = rs.getString(3);
                String notes = rs.getString(4);
                String assigned = rs.getString(5);
                tlap = new Laptop(serial, type, manu, notes);
                tempsearch.add(tlap);
                //tablemodel.addRow(new Object[]{serial, type,manu}); // add the data to the row
                searchtablemodel.addRow(new Object[]{serial, type,manu, notes, assigned}); // add the data to the row
                //tablemodel.addRow(new Object[]{type});
                //tablemodel.addRow(new Object[]{manu});
                System.out.println( serial +" " + type  + " " + manu);
                countrow++;
            }
            System.out.println("Count Row: " + countrow);
            editB.setEnabled(true);
        }catch(Exception e){
            System.err.println(e);
            editB.setEnabled(false);
        }
        
        */
        
        return laps;
    }
    
    /**
     * 
     * @param model String - model to search
     * @return ArrayList<Laptop> - Listing of Laptops
     * @throws SQLException 
     */
    public ArrayList<Laptop> searchModel(String searchmodel)throws SQLException{
        // check if table exists
        if( !tableExists("laptopinventory")){
            System.out.println("laptopinventory doesn't exist");
            // doesn't exist, need to create it
            createTable();
        }else
            System.out.println("laptopinventory EXISTS");
        
        Laptop l = null;
        // use ArrayList to hold objects
        ArrayList<Laptop> laps = new ArrayList<Laptop>(); 
        
        String sql = "select * from laptopinventory where Model like '%" + searchmodel + "%' and assigned='no' ";
        
        Connection con = dbmodel.getConnection();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);
        while(rs.next()){
            String serial = rs.getString("Serial");
            String model = rs.getString("Model");
            String manuf = rs.getString("Manufacture");
            String notes = rs.getString("Notes");
            l = new Laptop(serial, model, manuf);
            l.setNotes(notes);
            System.out.println(l);
            laps.add(l); // add laptop to the ArrayList
        }
        
        return laps;
        
    }
    
    public ArrayList<Laptop> listAll()throws SQLException{
        ArrayList<Laptop> laps = new ArrayList<Laptop>();
        
        String sql = "select * from laptopinventory";
        
        // check if table exists
        if( !tableExists("laptopinventory")){
            System.out.println("laptopinventory doesn't exist");
            // doesn't exist, need to create it
            createTable();
        }else
            System.out.println("laptopinventory EXISTS");
        
        
        Connection con = dbmodel.getConnection();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);
        
        Laptop l = null;
        while(rs.next()){
            String serial = rs.getString("Serial");
            String model = rs.getString("Model");
            String manuf = rs.getString("Manufacture");
            String notes = rs.getString("Notes");
            
            l = new Laptop(serial, model, manuf);
            l.setNotes(notes);
            System.out.println(l);
            laps.add(l); // add laptop to the ArrayList
        }
        
        
        return laps;
        
    }
    
    // check if Laptop exists in DB, search via Serial ID
    public boolean isLaptopExist(String serialid){
        boolean exists = false;
        
        String sql = "select serialid from table where serialid=?";
        
        
        return exists;
    }
}
