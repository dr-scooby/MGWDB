/*
 * DBModel handles the database connection
 * close connection, etc..
 */
package Database;

import java.sql.*;
import java.util.*;
import java.io.*;

/**
 *
 * @author jismailx
 */
public class DBModel {
    
    private String driver = "com.mysql.jdbc.Driver";
    private String serverip = "192.168.56.4"; // Mint VM
    private String dbname = "Hawk";
    private String url = "jdbc:mysql://"+serverip+":3306/"+dbname;
    private String username = "nurali";
    private String pass = "123";
    
    private Connection con;
    
    // default constructor
    public DBModel(){
        
        System.out.println("Starting DBModel...");
        //props();
        
        try{
            Class.forName(driver);
        }catch(Exception e){
            System.err.println("Error loading driver\n" + e);
        }
        
//        System.out.println("URL: " + url);
//        try{
//            con = DriverManager.getConnection(url, username, pass);
//            if(con != null)
//                System.out.println("DB connected");
//        }catch(SQLException sql){
//            System.err.println(sql);
//        }
        
    }
    
    /**
     * 
     * @param ip
     * @param user
     * @param password 
     * @param dbname
     */
    public DBModel(String ip, String user, String password, String dbname){
        this.serverip = ip;
        this.username = user;
        this.pass = password;
        this.dbname = dbname;
        
        try{
            Class.forName(driver);
        }catch(Exception e){
            System.err.println("Error loading driver\n" + e);
        }
        
        url = "jdbc:mysql://"+serverip+":3306/"+dbname;
        System.out.println("URL: " + url);
        
        try{
            con = DriverManager.getConnection(url, username, pass);
            if(con != null)
                System.out.println("DB connected");
        }catch(SQLException sql){
            System.err.println(sql);
        }
        
    }
    
    
    
    // get a database Connection
    public Connection getConnection(){
        try{
        if( con.isClosed()){
            try{
            con = DriverManager.getConnection(url, username, pass);
            if(con != null)
                System.out.println("DB connected");
            }catch(SQLException sql){
                System.err.println(sql);
            } 
        }
        }catch(SQLException s){
            System.err.println(s);
        }
        
        if(con == null){
           try{
            con = DriverManager.getConnection(url, username, pass);
            if(con != null)
                System.out.println("DB connected");
            }catch(SQLException sql){
                System.err.println(sql);
            } 
        }
        
        return con;
    }
    
    // close the DB connection
    public void close(){
        try{
            con.close();
        }catch(SQLException s){
            System.err.println(s);
        }
    }
    
    // testing only
    private void props(){
        Properties props = new Properties();
        String url = "dbproperties.properties";
        try{
        InputStream input = new FileInputStream(url);
        props.load(input);
        System.out.println("DB user: " + props.getProperty("db.user"));
        System.out.println("DB password: " + props.getProperty("db.password"));
        System.out.println("DB ip: " + props.getProperty("db.ip"));
        }catch(IOException io){
            System.err.print(io);
        }
        
    }
    
}
