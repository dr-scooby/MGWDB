/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data;
import Database.*;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jismailx
 */
public abstract class DAO {
    
    // hangle the DBModel
    protected DBModel dbmodel;
    
    
    // default Constructor
    public DAO(){
        
    }
    
    public DAO(DBModel db){
        this.dbmodel = db;
    }
    
    
    public abstract void  add(String serial);
    
    public abstract void addLaptop(Laptop l) throws SQLException;
    
    public abstract ArrayList<Laptop> searchSerialID(String serialid)throws SQLException ;
    
}
