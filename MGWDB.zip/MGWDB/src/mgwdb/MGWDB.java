/*
 * Main application entry point
 */
package mgwdb;

import Database.DBModel;
import GUI.JaFrame;
import utils.Properties;

/**
 *
 * @author jismailx
 */
public class MGWDB {
    
    private DBModel db;
    
    
    public MGWDB(){
        
        // get the properties file info
        Properties props = new Properties();
        
        // DBModel(String ip, String user, String password, String dbname)
        // start the DBModel
        db = new DBModel(props.getIP(), props.getUser(), props.getPassword(), props.getDBName());
        
        // launch the View/GUI
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JaFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JaFrame view = new JaFrame();
                        view.setVisible(true);
                view.setDB(db);
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new MGWDB();
    }
    
}
